public class Task3 implements Task
{
        private static int k;

        public void execute()
        {
                k++;
                System.out.println(k);
        }
}
