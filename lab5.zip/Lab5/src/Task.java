public interface Task 
{
        /**
         * Executa actiunea caracteristica task-ului
         */
        void execute();
}
                             