/**
 * Enumera tipurile de strategii pentru containere
 * @author marius-andrei
 *
 */
public enum Strategy 
{
        FIFO, LIFO
}
